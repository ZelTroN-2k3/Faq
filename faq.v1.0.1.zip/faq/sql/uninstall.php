<?php
$sql = array();
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'faq`';
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'faq_lang`';

?>