# Prestashop FAQ module

## About

Prestashop module cr�er une page de FAQ avec des questions et r�ponses.

## Compatibility

Tested on
* Prestashop 1.6.0.14
* Prestashop 1.6.1.15


### TODO
- Make it compatible with PrestaShop 1.6 / 1.7

## License

Copyright (c) 2016 bortonecesario

Ce module permet aux administrateurs de BO de cr�er une page de FAQ avec des questions et r�ponses.
Le module ajoute un lien dans le bloc d'informations du pied de page et un lien dans le menu du haut.

J'ai test� le module avec Bootstrap Theme et PS 1.6

Ceci est mon premier module alors laissez-moi savoir si quelque chose ne va pas lors de l'installation
Si vous aimez le module, vous pouvez m'envoyer un don via paypal �: cesario.bortone@hotmail.it